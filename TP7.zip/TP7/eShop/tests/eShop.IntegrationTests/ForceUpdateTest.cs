﻿using eShop.IntegrationTests;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

public class ForceUpdateTest : IntegrationTest
{
    public ForceUpdateTest(TestWebApplicationFactory factory) : base(factory)
    {
    }

    [Theory]
    [InlineData("1.0.0")]
    [InlineData("2.0.0")]
    [InlineData("")]
    public async Task ForceUpdate_ShouldReturnExpectedResult(string appVersion)
    {
        var requestUri = "/api/some-endpoint";

        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        request.Headers.Add("app-version", appVersion);
        var response = await _httpClient.SendAsync(request);

        if (string.IsNullOrEmpty(appVersion) || appVersion.CompareTo("1.0.0") < 0)
        {
            Assert.Equal(HttpStatusCode.PreconditionFailed, response.StatusCode);
        }
        else
        {
            response.EnsureSuccessStatusCode();
        }
    }
}
