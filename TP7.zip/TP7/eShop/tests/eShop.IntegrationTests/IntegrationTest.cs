﻿using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace eShop.IntegrationTests
{
    public abstract class IntegrationTest : IClassFixture<TestWebApplicationFactory>
    {
        private readonly TestWebApplicationFactory _factory;
        protected HttpClient _httpClient;

        public IntegrationTest(TestWebApplicationFactory factory)
        {
            _factory = factory;
            _httpClient = _factory.WithWebHostBuilder(builder =>
            {
                builder.ConfigureServices(services =>
                {


                });
            }).CreateClient();
        }
    }

    public class TestWebApplicationFactory : WebApplicationFactory<Program>
    {
    }
}
