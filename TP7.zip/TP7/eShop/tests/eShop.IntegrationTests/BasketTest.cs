﻿using eShop.Core.Entities;
using eShop.IntegrationTests;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Xunit;

public class BasketTest : IntegrationTest
{
    public BasketTest(TestWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task GetBasket_ShouldReturnSuccessStatusCode()
    {

        var response = await _httpClient.GetAsync("/api/basket");

        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<IEnumerable<Basket>>();
        Assert.NotNull(result);
    }

    [Fact]
    public async Task NonExistentEndpoint_ShouldReturnNotFoundStatusCode()
    {

        var nonExistentEndpoint = "/api/basket/nonexistent";

        var response = await _httpClient.GetAsync(nonExistentEndpoint);

        
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task CreateAndRetrieveBasket_ShouldSucceed()
    {
        
        var newBasket = new Basket
        {
            ProductId = 1,
            Quantity = 2
        };

        
        var createResponse = await _httpClient.PostAsJsonAsync("/api/basket", newBasket);
        createResponse.EnsureSuccessStatusCode();

        var createdBasket = await createResponse.Content.ReadFromJsonAsync<Basket>();

        var retrieveResponse = await _httpClient.GetAsync($"/api/basket/{createdBasket.Id}");
        retrieveResponse.EnsureSuccessStatusCode();

        var retrievedBasket = await retrieveResponse.Content.ReadFromJsonAsync<Basket>();

        
        Assert.NotNull(retrievedBasket);
        Assert.Equal(createdBasket.Id, retrievedBasket.Id);
        Assert.Equal(newBasket.ProductId, retrievedBasket.ProductId);
        Assert.Equal(newBasket.Quantity, retrievedBasket.Quantity);
    }

    [Fact]
    public async Task AddItemToBasket_ShouldReturnSuccessStatusCode()
    {
        var basketId = "someBasketId";
        var productToAdd = new BasketItem { CatalogItemId = 1, Quantity = 3, UnitPrice = 10.0m };


        var response = await _httpClient.PutAsJsonAsync($"/api/basket/{basketId}", productToAdd);

        response.EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

    }

    [Fact]
    public async Task DeleteBasket_ShouldReturnSuccessStatusCode()
    {

        var basketIdToDelete = "someBasketId";

        var response = await _httpClient.DeleteAsync($"/api/basket/{basketIdToDelete}");


        response.EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);

    }
}
