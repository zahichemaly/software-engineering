﻿namespace RMS
{
    public class MenuItem
    {
        public string name { get; set; }
        public decimal price { get; set; }
        public int currency { get; set; }
        public int quantity { get; set; }

        public MenuItem(string name, decimal price)
        {
            this.name = name;
            this.price = price;
        }
    }

}   
