﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    public interface IMenuItem
    {
        string Name { get; }
        decimal CalculatePrice();
    }
}
