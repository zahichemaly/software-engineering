﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    public class SpecialMenuItem : IMenuItem
    {
        private string _name;
        private decimal _price;
        private decimal _specialPrice;
        private int _currency;
        private DayOfWeek _dayOfWeek;



        public SpecialMenuItem(string name, decimal price, DayOfWeek dayOfWeek, decimal specialPrice, int currency = 0)
        {
            _name = name;
            _price = price;
            _dayOfWeek = dayOfWeek;
            _specialPrice = specialPrice;
            _currency = currency;
        }



        public string Name => _name;



        public decimal CalculatePrice()
        {
            decimal totalPrice = (_dayOfWeek == DateTime.Today.DayOfWeek) ? _specialPrice : _price;
            if (_currency == 1)
            {
                totalPrice *= 1.1m;
            }
            return totalPrice;
        }
    }

}
