﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    public class RegularMenuItem : IMenuItem
    {
        private string _name;
        private decimal _price;
        private int _currency;



        public RegularMenuItem(string name, decimal price, int currency = 0)
        {
            _name = name;
            _price = price;
            _currency = currency;
        }


        public string Name => _name;



        public decimal CalculatePrice()
        {
            decimal totalPrice = _price;
            if (_currency == 1)
            {
                totalPrice *= 1.1m;
            }
            return totalPrice;
        }
    }

}
