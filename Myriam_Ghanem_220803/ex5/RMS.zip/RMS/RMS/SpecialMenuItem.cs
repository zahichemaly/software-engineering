﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    public class SpecialMenuItem : IMenuItem
    {
        private string _name;
        private decimal _price;
        private decimal _specialPrice;
        private int _currency;
        private DayOfWeek _specialDay;

        public SpecialMenuItem(string name, decimal price, DayOfWeek specialDay, decimal specialPrice, int currency = 0)
        {
            _name = name;
            _price = price;
            _specialDay = specialDay;
            _specialPrice = specialPrice;
            _currency = currency;
        }

        public string Name => _name;

        public decimal CalculatePrice()
        {
            if (DateTime.Now.DayOfWeek == _specialDay)
            {
                decimal totalPrice = _specialPrice;
                if (_currency == 1)
                {
                    totalPrice *= 1.1m;
                }
                return totalPrice;
            }
            else
            {
                decimal totalPrice = _price;
                if (_currency == 1)
                {
                    totalPrice *= 1.1m;
                }
                return totalPrice;
            }
        }
    }


}
