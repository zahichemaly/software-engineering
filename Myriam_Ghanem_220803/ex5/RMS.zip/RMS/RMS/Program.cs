﻿using RMS;

class Program
{
    static void Main(string[] args)
    {
        Menu menu = new Menu();

        IMenuItem menuItem = new RegularMenuItem("Burger", 10.0m);
        IMenuItem menuItem2 = new RegularMenuItem("French Fries", 2.0m, 1);

        // Create separate instances of menu items
        IMenuItem orderItem1 = new RegularMenuItem(menuItem.Name, menuItem.CalculatePrice());
        IMenuItem orderItem2 = new RegularMenuItem(menuItem2.Name, menuItem2.CalculatePrice());

        menu.MenuItems.Add(menuItem);
        menu.MenuItems.Add(menuItem2);

        IMenuItem specialMenuItem = new SpecialMenuItem("Pizza", 16.0m, DateTime.Now.DayOfWeek, 12.0m);
        menu.MenuItems.Add(specialMenuItem);

        List<IMenuItem> order = new List<IMenuItem>()
        {
            orderItem1,
            orderItem2,
            specialMenuItem
        };

        decimal total = menu.CalculateTotalPrice(order);
        Console.WriteLine("Total Price: " + total.ToString("0.00"));
    }
}
