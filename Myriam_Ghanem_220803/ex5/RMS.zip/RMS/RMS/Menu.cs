﻿namespace RMS
{
    public class Menu
    {
        public List<IMenuItem> MenuItems { get; set; }

        public Menu()
        {
            MenuItems = new List<IMenuItem>();
        }

        public decimal CalculateTotalPrice(List<IMenuItem> order)
        {
            decimal total = 0;
            foreach (var item in order)
            {
                total += item.CalculatePrice();
            }
            return total;
        }
    }
}

