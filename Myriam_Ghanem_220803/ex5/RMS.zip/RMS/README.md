# Restaurant Menu System (RMS)
This repo contains C# code that was written with no respect to **SOLID** principles, **coding conventions** and **best practices**.

It is up to you to fix it.
