﻿namespace eShop.Infrastructure.Data
{
    public sealed class MongoSettings
    {
        public string MongoConnection { get; set; }
        public string MongoDatabaseName { get; set; }
    }
}
