﻿using System;
using eShop.Core.Entities;
using eShop.Core.Exceptions;
using eShop.Core.Interfaces;
using eShop.Core.Managers;
using Moq;

namespace eShop.UnitTests
{
	public class PaymentManagerTest
	{
        private readonly Mock<IPaymentService> _paymentServiceMock;
        private readonly Mock<IAppLogger<PaymentManager>> _loggerMock;
        private readonly PaymentManager _paymentManager;

        public PaymentManagerTest()
        {
            _paymentServiceMock = new Mock<IPaymentService>();
            _loggerMock = new Mock<IAppLogger<PaymentManager>>();

            _paymentManager = new PaymentManager(_paymentServiceMock.Object, _loggerMock.Object);
        }

        [Fact]
        public void ValidateAndPlaceOrder_WithExpiredCreditCard_ThrowsCreditCardExpiredException()
        {
            var paymentServiceMock = new Mock<IPaymentService>();
            var loggerMock = new Mock<IAppLogger<PaymentManager>>();
            var paymentManager = new PaymentManager(paymentServiceMock.Object, loggerMock.Object);

            var expiredCreditCard = new CreditCard
            {
                Expiration = DateTime.UtcNow.AddDays(-1),
            };

            var basket = new Basket("buyerId");
            basket.AddItem(1, 100, 1);

            var order = new Order(basket, new Contact(), expiredCreditCard);

            Assert.Throws<CreditCardExpiredException>(() => paymentManager.ValidateAndPlaceOrder(order));
        }



        [Fact]
        public void ValidateAndPlaceOrder_WithInsufficientFunds_ThrowsCreditCardInsufficientAmountException()
        {
            var paymentServiceMock = new Mock<IPaymentService>();
            var loggerMock = new Mock<IAppLogger<PaymentManager>>();
            var paymentManager = new PaymentManager(paymentServiceMock.Object, loggerMock.Object);

            var creditCard = new CreditCard
            {
                Type = CreditCardType.VISA,
                CardHolderName = "Test Holder",
                Number = "1234567890123456",
                Expiration = DateTime.UtcNow.AddYears(1),
                SecurityCode = "123"

            };

            var basket = new Basket("buyerId");
            basket.AddItem(1, 100, 1); 

            var order = new Order(basket, new Contact(), creditCard);
            decimal cardHoldAmount = 200;
            paymentServiceMock.Setup(service => service.GetHoldOfCard(creditCard)).Returns(cardHoldAmount);


            Assert.Throws<CreditCardInsufficientAmountException>(() => paymentManager.ValidateAndPlaceOrder(order));
        }



    }

}
