﻿using System;
using eShop.Core.Interfaces;
using eShop.Core.Managers;
using Moq;

namespace eShop.UnitTests
{
	public class EmailManagerTest
	{
        private readonly Mock<IEmailSender> _emailSenderMock;
        private readonly Mock<IAppLogger<EmailManager>> _loggerMock;
        public EmailManagerTest()
        {
            _emailSenderMock = new Mock<IEmailSender>();
            _loggerMock = new Mock<IAppLogger<EmailManager>>();
        }

        [Fact]
        public void TrySend_ValidEmailAndNonEmptySubject_ShouldSendEmail()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);

            _emailSenderMock.Setup(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(true);

            string validEmail = "test@usj.edu.lb";
            string nonEmptySubject = "Hello";
            string message = "This is a test email.";

            bool result = emailManager.TrySend(validEmail, nonEmptySubject, message);

            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(),
It.IsAny<string>()), Times.Once());

            Assert.True(result);
            _emailSenderMock.Verify(x => x.SendEmail(validEmail, nonEmptySubject, message), Times.Once);
        }

        [Fact]
        public void TrySend_ValidEmailAndEmptySubject_ShouldNotSendEmail()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);

            string validEmail = "test@example.com";
            string emptySubject = "";
            string message = "This is a test email.";

            bool result = emailManager.TrySend(validEmail, emptySubject, message);

            Assert.False(result);
            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public void TrySend_InvalidEmailAndNonEmptySubject_ShouldNotSendEmail()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);

            string invalidEmail = "notanemail";
            string nonEmptySubject = "Hello";
            string message = "This is a test email.";

            bool result = emailManager.TrySend(invalidEmail, nonEmptySubject, message);

            Assert.False(result);
            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public void TrySend_InvalidEmailAndEmptySubject_ShouldNotSendEmail()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);

            string invalidEmail = "notanemail";
            string emptySubject = "";
            string message = "This is a test email.";

            bool result = emailManager.TrySend(invalidEmail, emptySubject, message);

            Assert.False(result);
            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public void TrySend_NonUSJEmail_ShouldNotSendEmail()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);

            string nonUSJEmail = "user@nonusjdomain.com";
            string subject = "Test Subject";
            string message = "This is a test email.";

            bool result = emailManager.TrySend(nonUSJEmail, subject, message);

            Assert.False(result, "Email should not be sent if it's not from the USJ domain.");
            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

    }
}

