﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Moq;
using Xunit;
using eShop.Core.Entities;
using eShop.Core.Interfaces;
using eShop.Core.Managers;

namespace eShop.UnitTests
{
    public class NotificationManagerTests
    {
        private readonly Mock<IRepository<User>> _userRepositoryMock;
        private readonly Mock<IEmailSender> _emailSenderMock;
        private readonly Mock<IAppLogger<EmailManager>> _loggerMock;
        private readonly NotificationManager _notificationManager;

        public NotificationManagerTests()
        {
            _userRepositoryMock = new Mock<IRepository<User>>();
            _emailSenderMock = new Mock<IEmailSender>();
            _loggerMock = new Mock<IAppLogger<EmailManager>>();
            _notificationManager = new NotificationManager(_emailSenderMock.Object, _loggerMock.Object, _userRepositoryMock.Object);
        }

        [Fact]
        public void SendEmail_ShouldBeCalledOnce()
        {
            var emailManager = new EmailManager(_emailSenderMock.Object, _loggerMock.Object);
            string validEmail = "test@usj.edu.lb";
            string subject = "Subject";
            string message = "Message";

            _emailSenderMock.Setup(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                            .Returns(true);

            emailManager.TrySend(validEmail, subject, message);

            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once());
        }

        [Fact]
        public async Task SendEmails_ShouldCallSendEmailBasedOnUserCount()
        {
            var inactiveUsers = new List<User>
{
    new User { Email = "user1@net.usj.edu.lb", LastActive = DateTime.UtcNow.AddMonths(-2) },
    new User { Email = "user2@usj.edu.lb", LastActive = DateTime.UtcNow.AddMonths(-2) }
};




            _userRepositoryMock.Setup(repo => repo.GetAllAsync()).ReturnsAsync(inactiveUsers);

            await _notificationManager.SendEmailsToInactiveUsers();

            Assert.True(inactiveUsers.All(u => u.LastActive <= DateTime.UtcNow.AddMonths(-1)),
                "All users should be considered inactive");
            _emailSenderMock.Verify(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()),
                                    Times.Exactly(inactiveUsers.Count));
        }


    }
}