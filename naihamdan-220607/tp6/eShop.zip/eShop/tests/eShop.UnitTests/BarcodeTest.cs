﻿using System;
using eShop.Core.Entities;

namespace eShop.UnitTests
{
	public class BarcodeTest
	{
        public static IEnumerable<object[]> InvalidSkuLengthData = new List<object[]> {
            new object[] { "invalid_sku" },
            new object[] { "invalid_sku_1" },
            new object[] { "invalid_sku_2" }
        };

        public BarcodeTest()
		{
		}



        [Theory]
        [InlineData(null)]
        [InlineData("")]
        public void Create_Should_Return_Null_When_Value_Is_NullOrEmpty(string value)
        {
            var barcode = Barcode.Create(value);
            Assert.Null(barcode);
        }

        [Theory]
        [MemberData(nameof(InvalidSkuLengthData))]
        public void Create_Should_Fail_With_Invalid_Sku_Length(string value)
        {
            var barcode = Barcode.Create(value);

            Assert.Null(barcode);
        }


        [Theory]
        [ClassData(typeof(BarcodeTestData))]
        public void Create_Should_Succeed_With_Exact_15_Char_Length(Barcode barcode)
        {
            Assert.NotNull(barcode);
            Assert.Equal(15, barcode.Value.Length);
        }

    }

    public class BarcodeTestData : TheoryData<Barcode>
    {
        public BarcodeTestData()
        {
            Add(Barcode.Create("123456789012345"));
        }
    }
}

