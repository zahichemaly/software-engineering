﻿using System;
using eShop.Core.Entities;

namespace eShop.UnitTests
{
	public class BasketItemTest
	{

        [Fact]
        public void Constructor_Should_Set_Values_Correctly()
        {
            int expectedCatalogItemId = 1;
            int expectedQuantity = 5;
            decimal expectedUnitPrice = 10m;

            var basketItem = new BasketItem(expectedCatalogItemId, expectedQuantity, expectedUnitPrice);

            Assert.Equal(expectedCatalogItemId, basketItem.CatalogItemId);
            Assert.Equal(expectedQuantity, basketItem.Quantity);
            Assert.Equal(expectedUnitPrice, basketItem.UnitPrice);
        }

        [Fact]
        public void AddQuantity_Should_Increment_Quantity()
        {
            var basketItem = new BasketItem(1, 1, 10m);
            int quantityToAdd = 5;
            int expectedQuantity = 6;

            basketItem.AddQuantity(quantityToAdd);

            Assert.Equal(expectedQuantity, basketItem.Quantity);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(-100)]
        public void AddQuantity_Should_Throw_ArgumentOutOfRangeException_When_Negative(int quantityToAdd)
        {
            var basketItem = new BasketItem(1, 1, 10m);

            Assert.Throws<ArgumentOutOfRangeException>(() => basketItem.AddQuantity(quantityToAdd));
        }

        [Theory]
        [InlineData(0)]
        [InlineData(10)]
        [InlineData(100)]
        public void SetQuantity_Should_Set_Quantity_Correctly(int newQuantity)
        {
            var basketItem = new BasketItem(1, 1, 10m);

            basketItem.SetQuantity(newQuantity);

            Assert.Equal(newQuantity, basketItem.Quantity);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(-100)]
        public void SetQuantity_Should_Throw_ArgumentOutOfRangeException_When_Negative(int newQuantity)
        {
            var basketItem = new BasketItem(1, 1, 10m);

            Assert.Throws<ArgumentOutOfRangeException>(() => basketItem.SetQuantity(newQuantity));
        }

        [Fact]
        public void GetTotalPrice_Should_Calculate_Correctly()
        {
            var basketItem = new BasketItem(1, 2, 10m);
            decimal expectedTotal = 20m;

            var total = basketItem.GetTotalPrice();

            Assert.Equal(expectedTotal, total);
        }

    }
}


