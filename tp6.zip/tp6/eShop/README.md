# eShop Sample app for Unit Testing 🧪
This is a sample .NET project that follows **Clean Architecture** and uses **MongoDB** as a database.
It can be unit tested by creating an **xUnit test project** and referencing the **Core** module.
